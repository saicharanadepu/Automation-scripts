package Testcases;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Reusables.BaseTest;
import Reusables.Browsers;
import Reusables.Steps;
import Reusables.common_methods;

public class VerifyPolicyTradeHomeTestCase extends BaseTest {
	
	
	@BeforeTest
	public void StartTest() {
		
		initializeReport();
	}
	@Test(groups= {"SmokeTest"})
	public void verifyHome() throws IOException {
		try {
		String methodName = new Exception().getStackTrace()[0].getMethodName();
		test = extent.createTest(methodName,"VerifyPolicyTradeHomeTestCase");
		Properties prop = readPropertiesFile(".\\src\\test\\java\\Config\\Application.properties");
		String url=prop.getProperty("Application_url");
		Steps s=new Steps();
		s.launch_url(url);
		test.log(Status.PASS, "Launch Completed");
		s.verifyHomeBanner();
		s.verifylenderpopup();
//		s.verifypoolinHome();
//		s.verifyOverViewDataInHome();
		}
		catch(Exception e) {
			Takescreenshot(new Browsers().getDriver(), "./src/Screenshots/PolicyTradeHome.jpg");
		}
	}

}
