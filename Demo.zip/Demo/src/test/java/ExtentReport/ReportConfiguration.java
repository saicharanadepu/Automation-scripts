package ExtentReport;


import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import Reusables.common_methods;
public class ReportConfiguration  extends common_methods{
 
	 public static ExtentSparkReporter htmlReporter;
	 public static ExtentReports extent;
	 public static ExtentTest test;
 
 public static ExtentTest logger;
 
 public  void ExtendReportConfiguraiton() {
  System.out.print(System.getProperty("user.dir"));
  htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir") + "/test-output/ExtentReport/ExtentReport.html");
  extent = new ExtentReports();
  htmlReporter.config().setDocumentTitle("Automation Report Demo Test");
  htmlReporter.config().setReportName("Demo Test Report");
  htmlReporter.config().setTheme(Theme.STANDARD);
  htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
  extent = new ExtentReports();

  extent.attachReporter(htmlReporter);   

  
 }
 

}
