package Reusables;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import ExtentReport.ReportConfiguration;

public class BaseTest extends ReportConfiguration{
	    public WebDriver driver;
		String Browsertype;
		Properties prop ;
		String url;
		
		
	    @BeforeTest(groups= {"SmokeTest"})
		public void setup() throws IOException {
			prop = readPropertiesFile(".\\src\\test\\java\\Config\\Application.properties");
			Browsertype=prop.getProperty("Browser");
			url=prop.getProperty("Application_url");
			Browsers.SetWebDriver(Browsertype);
			ReportConfiguration reportConfiguration = new ReportConfiguration();
			reportConfiguration.ExtendReportConfiguraiton();
		}
		
//	    @AfterTest
//	    public void getResult(ITestResult result) throws Exception{
//	    	if(result.getStatus() == ITestResult.FAILURE){
//	    	//MarkupHelper is used to display the output in different colors
//	    	logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
//	    	logger.log(Status.FAIL, MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));
//	    	
//	    	String screenshotPath = common_methods.getScreenShot(driver, result.getName());
//	    	
//	    	logger.fail("Test Case Failed Snapshot is below " + logger.addScreenCaptureFromPath(screenshotPath));
//	    	}
//	    	else if(result.getStatus() == ITestResult.SKIP){
//	    	logger.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.ORANGE));
//	    	}
//	    	else if(result.getStatus() == ITestResult.SUCCESS)
//	    	{
//	    	logger.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));
//	    	}
//	    	driver.quit();
//	    	}
	    
	    @AfterTest 
	    public void flushReports() {
	    	extent.flush();
			
	    }
	    
	    public void initializeReport(){
			 
			 ExtentSparkReporter htmlReporter =  new ExtentSparkReporter(System.getProperty("user.dir")+"/Reports/Test.html");
			    htmlReporter.config().setDocumentTitle("Automation Report Demo Test");
			    htmlReporter.config().setReportName("Demo Test Report");
			    htmlReporter.config().setTheme(Theme.STANDARD);
			    htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
			    extent = new ExtentReports();
			    extent.attachReporter(htmlReporter);   
			}
		 
	    }